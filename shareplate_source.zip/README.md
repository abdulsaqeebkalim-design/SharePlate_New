# SharePlate
Local food donation app with AI analysis.